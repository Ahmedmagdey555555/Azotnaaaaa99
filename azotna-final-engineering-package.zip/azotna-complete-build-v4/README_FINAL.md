# عزوتنا — Final Engineering Package

This is the consolidated engineering package for the Assiut-first delivery platform.

## What you can do with it
- Continue backend implementation against PostgreSQL.
- Run local PostgreSQL with Docker Compose.
- Build the Flutter customer and driver shells.
- Implement merchant/admin web dashboards.
- Connect external providers through the defined interfaces.

## Important
This package is not a magically published App Store/Google Play product. Publishing and external services require real accounts, credentials, domains and production infrastructure. No credentials are included in this repository.

## Current commercial defaults
- City: Assiut
- Cash on delivery: enabled
- Cards: disabled initially
- Driver custody: 700 EGP starting cap
- Special orders: enabled
- All distances: configuration-driven
