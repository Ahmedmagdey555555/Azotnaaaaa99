import 'package:flutter/material.dart';
import 'core/api_client.dart';

void main()=>runApp(const DriverApp());

class DriverApp extends StatefulWidget{
 const DriverApp({super.key});
 @override State<DriverApp> createState()=>_DriverState();
}
class _DriverState extends State<DriverApp>{
 final api=ApiClient(); bool online=false; String msg=''; Map<String,dynamic>? custody;

 Future<void> refresh() async {
   try{ final r=await api.get('/driver/custody'); setState(()=>custody=r); }
   catch(_){setState(()=>msg='السيرفر غير متصل حالياً');}
 }
 Future<void> toggle(bool value) async {
   try{final r=await api.post('/driver/availability',{'online':value});setState(()=>online=r['online']??value);}
   catch(_){setState(()=>msg='تعذر تغيير الحالة');}
 }

 @override Widget build(BuildContext c)=>MaterialApp(
   debugShowCheckedModeBanner:false,title:'عزوتنا للمندوب',
   theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.deepOrange),
   home:Directionality(textDirection:TextDirection.rtl,child:Scaffold(
     appBar:AppBar(title:const Text('عزوتنا — المندوب'),actions:[
       IconButton(onPressed:refresh,icon:const Icon(Icons.refresh))
     ]),
     body:ListView(padding:const EdgeInsets.all(16),children:[
       SwitchListTile(value:online,onChanged:toggle,title:const Text('متاح لاستقبال الطلبات')),
       Card(child:ListTile(title:const Text('العهدة'),
         subtitle:Text('${custody?['balance']??0} جنيه'),
         trailing:Text('السقف ${custody?['limit']??700}'))),
       const Card(child:ListTile(title:Text('أرباح اليوم'),subtitle:Text('تظهر بعد استلام الطلبات'))),
       Card(child:ListTile(title:const Text('طلبات متاحة'),
         subtitle:Text(online?'سيتم توزيع الطلبات حسب الموقع ونوع المركبة':'فعّل متاح أولاً'))),
       if(msg.isNotEmpty)Text(msg)
     ])));
}
