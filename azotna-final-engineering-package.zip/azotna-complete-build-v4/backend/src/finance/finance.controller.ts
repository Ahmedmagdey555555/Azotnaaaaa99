import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { LedgerService } from './ledger.service';

@Controller('finance')
export class FinanceController {
 constructor(private readonly ledger:LedgerService){}
 @Post('ledger') add(@Body() b:{driverId?:string;orderId?:string;type:string;amount:number;note?:string}){return this.ledger.add(b);}
 @Get('ledger') all(){return {data:this.ledger.all()};}
 @Get('drivers/:id/ledger') driver(@Param('id') id:string){return {data:this.ledger.byDriver(id)};}
}
