import { Injectable, BadRequestException } from '@nestjs/common';

export type Entry={id:string,driverId?:string,orderId?:string,type:string,amount:number,note?:string,createdAt:string};

@Injectable()
export class LedgerService {
  private entries:Entry[]=[];
  add(e:Omit<Entry,'id'|'createdAt'>){
    if(!Number.isFinite(e.amount)) throw new BadRequestException('Invalid amount');
    const x={...e,id:'LED-'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),createdAt:new Date().toISOString()};
    this.entries.push(x); return x;
  }
  byDriver(driverId:string){return this.entries.filter(x=>x.driverId===driverId);}
  all(){return this.entries;}
}
