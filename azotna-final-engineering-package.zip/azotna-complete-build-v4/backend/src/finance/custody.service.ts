import { BadRequestException, Injectable } from '@nestjs/common';

@Injectable()
export class CustodyService {
  initialLimit = 700;

  canCollect(balance:number, amount:number, limit:number) {
    return balance + amount <= limit;
  }

  collect(balance:number, amount:number, limit:number) {
    if(amount < 0 || !this.canCollect(balance, amount, limit))
      throw new BadRequestException('Custody limit exceeded');
    return +(balance + amount).toFixed(2);
  }

  settle(balance:number, amount:number) {
    if(amount <= 0 || amount > balance)
      throw new BadRequestException('Invalid settlement');
    return +(balance - amount).toFixed(2);
  }

  nextLimit(current:number, successfulSettles:number) {
    if(successfulSettles >= 30) return Math.max(current,2000);
    if(successfulSettles >= 15) return Math.max(current,1200);
    if(successfulSettles >= 7) return Math.max(current,900);
    return current;
  }
}
