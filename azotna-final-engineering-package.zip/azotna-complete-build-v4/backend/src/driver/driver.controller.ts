import { Body, Controller, Get, Post, Param } from '@nestjs/common';

@Controller('driver')
export class DriverController {
  @Get('profile') profile() {
    return {vehicle:'WALK',online:false,custodyBalance:0,custodyLimit:700,rating:5};
  }
  @Post('availability') availability(@Body() body:{online:boolean}) {
    return {online:!!body.online};
  }
  @Get('offers') offers() { return {data:[]}; }
  @Post('orders/:id/accept') accept(@Param('id') id:string) {
    return {id,status:'DRIVER_ASSIGNED'};
  }
  @Post('orders/:id/status') status(@Param('id') id:string,@Body() body:{status:string}) {
    return {id,status:body.status};
  }
  @Get('custody') custody() {
    return {balance:0,limit:700,available:700};
  }
  @Post('settlements') settlement(@Body() body:{amount:number}) {
    return {status:'PENDING_APPROVAL',amount:body.amount};
  }
}
