import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';

type O={id:string,status:string,customerId:string,driverId?:string,deliveryFee:number,driverEarning:number,platformMargin:number,cashDue:number};

@Injectable()
export class OrderEngineService {
  private orders=new Map<string,O>();
  create(input:any):O {
    const id='ORD-'+Date.now().toString(36).toUpperCase();
    const o:O={id,status:'CREATED',customerId:input.customerId||'CURRENT_CUSTOMER',
      deliveryFee:Number(input.deliveryFee||0),driverEarning:Number(input.driverEarning||0),
      platformMargin:Number(input.platformMargin||0),cashDue:Number(input.cashDue||0)};
    this.orders.set(id,o); return o;
  }
  get(id:string){const o=this.orders.get(id); if(!o) throw new NotFoundException('Order not found'); return o;}
  transition(id:string,to:string){
    const o=this.get(id);
    const allowed:Record<string,string[]>={
      CREATED:['CONFIRMED','CANCELLED'],CONFIRMED:['PREPARING','CANCELLED'],
      PREPARING:['READY_FOR_PICKUP','CANCELLED'],READY_FOR_PICKUP:['DRIVER_ASSIGNED','CANCELLED'],
      DRIVER_ASSIGNED:['DRIVER_ARRIVED','CANCELLED'],DRIVER_ARRIVED:['PICKED_UP','CANCELLED'],
      PICKED_UP:['ON_THE_WAY'],ON_THE_WAY:['DELIVERED'],DELIVERED:[],CANCELLED:[]
    };
    if(!(allowed[o.status]||[]).includes(to)) throw new BadRequestException(`Invalid transition ${o.status} -> ${to}`);
    o.status=to; return o;
  }
  assign(id:string,driverId:string){const o=this.transition(id,'DRIVER_ASSIGNED');o.driverId=driverId;return o;}
  list(){return [...this.orders.values()];}
}
