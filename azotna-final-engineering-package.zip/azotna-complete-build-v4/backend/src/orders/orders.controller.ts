import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { PricingService } from '../common/pricing.service';
import { OrderEngineService } from './order-engine.service';

@Controller('orders')
export class OrdersController {
  constructor(private readonly pricing:PricingService, private readonly engine:OrderEngineService) {}
  @Post('quote') quote(@Body() b:{distanceKm:number;special?:boolean}) {
    return this.pricing.quote(Number(b.distanceKm||0),!!b.special);
  }
  @Post() create(@Body() b:any) { return this.engine.create(b); }
  @Get() list(){return {data:this.engine.list(),total:this.engine.list().length};}
  @Get(':id') get(@Param('id') id:string){return this.engine.get(id);}
  @Post(':id/status') status(@Param('id') id:string,@Body() b:{status:string}){return this.engine.transition(id,b.status);}
  @Post(':id/assign') assign(@Param('id') id:string,@Body() b:{driverId:string}){return this.engine.assign(id,b.driverId);}
  @Post(':id/cancel') cancel(@Param('id') id:string){return this.engine.transition(id,'CANCELLED');}
}
