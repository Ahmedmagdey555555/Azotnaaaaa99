import { Module } from '@nestjs/common';
import { HealthController } from './common/health.controller';
import { AuthController } from './auth/auth.controller';
import { OrdersController } from './orders/orders.controller';
import { DriverController } from './driver/driver.controller';
import { MerchantController } from './merchant/merchant.controller';
import { AdminController } from './admin/admin.controller';
import { SpecialOrdersController } from './special-orders/special-orders.controller';
import { AuditController, ConfigController } from './admin/audit.controller';
import { ConfigController } from './common/config.controller';
import { PricingService } from './common/pricing.service';
import { OrderEngineService } from './orders/order-engine.service';
import { LedgerService } from './finance/ledger.service';
import { FinanceController } from './finance/finance.controller';

@Module({
  controllers: [
    HealthController, AuthController, OrdersController,
    DriverController, MerchantController, AdminController, SpecialOrdersController, AuditController, ConfigController, FinanceController
  ],
  providers: [PricingService, OrderEngineService, LedgerService],
})
export class AppModule {}
