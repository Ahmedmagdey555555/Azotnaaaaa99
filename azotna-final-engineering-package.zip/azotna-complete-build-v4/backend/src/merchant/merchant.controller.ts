import { Body, Controller, Get, Post, Param } from '@nestjs/common';

@Controller('merchant')
export class MerchantController {
  @Get('dashboard') dashboard() {
    return {newOrders:0,preparing:0,todaySales:0,pendingSettlements:0};
  }
  @Get('orders') orders() { return {data:[]}; }
  @Post('orders/:id/accept') accept(@Param('id') id:string) {
    return {id,status:'CONFIRMED'};
  }
  @Post('orders/:id/ready') ready(@Param('id') id:string) {
    return {id,status:'READY_FOR_PICKUP'};
  }
}
