import { Controller, Get } from '@nestjs/common';
@Controller('health')
export class HealthController {
  @Get() get() { return {ok:true, app:'azotna', version:'1.0.0'}; }
}
