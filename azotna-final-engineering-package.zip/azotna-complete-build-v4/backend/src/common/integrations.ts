export interface OtpProvider {
  send(phone:string):Promise<void>;
  verify(phone:string,code:string):Promise<boolean>;
}
export interface MapsProvider {
  route(from:{lat:number;lng:number},to:{lat:number;lng:number}):Promise<{distanceKm:number;durationMin:number}>;
}
export interface StorageProvider {
  put(buffer:Buffer,contentType:string):Promise<string>;
}
export interface PushProvider {
  send(userId:string,title:string,body:string,data?:Record<string,string>):Promise<void>;
}
