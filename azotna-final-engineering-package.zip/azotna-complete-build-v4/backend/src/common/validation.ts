import { BadRequestException } from '@nestjs/common';

export function requiredString(value:any,name:string):string {
  if(typeof value!=='string' || !value.trim()) throw new BadRequestException(`${name} is required`);
  return value.trim();
}
export function positiveNumber(value:any,name:string):number {
  const n=Number(value);
  if(!Number.isFinite(n) || n<0) throw new BadRequestException(`${name} is invalid`);
  return n;
}
export function latitude(value:any):number {
  const n=Number(value);
  if(!Number.isFinite(n) || n<-90 || n>90) throw new BadRequestException('latitude is invalid');
  return n;
}
export function longitude(value:any):number {
  const n=Number(value);
  if(!Number.isFinite(n) || n<-180 || n>180) throw new BadRequestException('longitude is invalid');
  return n;
}
