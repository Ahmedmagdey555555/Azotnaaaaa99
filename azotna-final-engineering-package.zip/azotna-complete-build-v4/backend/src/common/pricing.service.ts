import { Injectable } from '@nestjs/common';

@Injectable()
export class PricingService {
  quote(distanceKm:number, special=false) {
    const delivery = Math.max(15, 10 + distanceKm * 2 + (special ? 10 : 0));
    const driver = 8 + distanceKm * 1.2;
    return {
      distanceKm:Number(distanceKm.toFixed(2)),
      deliveryFee:Number(delivery.toFixed(2)),
      driverEarning:Number(driver.toFixed(2)),
      platformMargin:Number((delivery-driver).toFixed(2))
    };
  }
}
