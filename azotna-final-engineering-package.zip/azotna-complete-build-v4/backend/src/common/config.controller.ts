import { Controller, Get } from '@nestjs/common';
@Controller('config')
export class ConfigController {
  @Get('public') publicConfig(){
    return {
      city:'Assiut',
      supportedCategories:['RESTAURANTS','SUPERMARKETS','PHARMACIES','STORES','SPECIAL'],
      paymentMethods:['CASH_ON_DELIVERY'],
      initialDriverCustodyLimit:700,
      cardsEnabled:false
    };
  }
}
