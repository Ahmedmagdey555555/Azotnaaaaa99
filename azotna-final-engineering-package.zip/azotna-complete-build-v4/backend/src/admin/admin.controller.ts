import { Controller, Get, Patch, Param, Body } from '@nestjs/common';

@Controller('admin')
export class AdminController {
  @Get('dashboard') dashboard() {
    return {orders:0,customers:0,drivers:0,merchants:0,revenue:0};
  }
  @Get('drivers') drivers(){return {data:[]};}
  @Get('merchants') merchants(){return {data:[]};}
  @Get('finance') finance(){return {revenue:0,driverPayouts:0,platformMargin:0,cashOutstanding:0};}
  @Patch('drivers/:id/custody-limit')
  custody(@Param('id') id:string,@Body() body:{limit:number}) {
    return {driverId:id,newLimit:body.limit,auditRequired:true};
  }
}
