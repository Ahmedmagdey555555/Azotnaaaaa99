import { Controller, Get } from '@nestjs/common';
@Controller('admin/audit')
export class AuditController {
  @Get() list() {
    return {data:[], note:'Audit records are persisted by the production service.'};
  }
}
