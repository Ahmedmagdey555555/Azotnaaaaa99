import { Body, Controller, Get, Param, Post } from '@nestjs/common';

@Controller('special-orders')
export class SpecialOrdersController {
  @Post()
  create(@Body() body:{
    customerId:string; pickupAddress:string; pickupLat:number; pickupLng:number;
    dropoffAddress:string; dropoffLat:number; dropoffLng:number;
    requestedText?:string; attachmentUrl?:string;
  }) {
    return {id:'SPECIAL_PENDING_DB',status:'CREATED',data:body};
  }

  @Get(':id')
  get(@Param('id') id:string) {
    return {id,status:'CREATED',quote:null,requiresCustomerApproval:true};
  }

  @Post(':id/quote')
  quote(@Param('id') id:string,@Body() body:{purchase:number;specialFee:number;deliveryFee:number}) {
    const total=Number(body.purchase)+Number(body.specialFee)+Number(body.deliveryFee);
    return {id,status:'QUOTED',purchase:body.purchase,specialFee:body.specialFee,deliveryFee:body.deliveryFee,total};
  }

  @Post(':id/approve')
  approve(@Param('id') id:string) {
    return {id,status:'CUSTOMER_APPROVED',approved:true};
  }
}
