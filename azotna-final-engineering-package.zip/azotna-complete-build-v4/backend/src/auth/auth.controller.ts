import { Body, Controller, Post } from '@nestjs/common';

@Controller('auth')
export class AuthController {
  @Post('request-otp')
  requestOtp(@Body() body:{phone:string}) {
    return {accepted:true, phone:body.phone, provider:'OTP_PENDING'};
  }

  @Post('verify-otp')
  verifyOtp(@Body() body:{phone:string; code:string}) {
    return {
      verified: body.code.length > 0,
      accessToken: 'TOKEN_PENDING_PROVIDER',
      refreshToken: 'REFRESH_PENDING_PROVIDER'
    };
  }
}
