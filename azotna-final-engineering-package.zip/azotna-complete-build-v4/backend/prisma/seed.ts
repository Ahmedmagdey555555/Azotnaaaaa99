import { PrismaClient, Role } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  await prisma.user.upsert({
    where:{phone:'+201000000000'},
    update:{role:Role.OWNER,name:'عزوتنا Owner'},
    create:{phone:'+201000000000',role:Role.OWNER,name:'عزوتنا Owner'}
  });
  console.log('Seed complete');
}
main().finally(()=>prisma.$disconnect());
