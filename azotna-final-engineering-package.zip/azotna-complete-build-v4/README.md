# عزوتنا

منصة توصيل متعددة الأنواع تبدأ من أسيوط:
مطاعم + سوبر ماركت + صيدليات + متاجر + طلب خاص.

## التطبيقات
- customer_app
- driver_app
- merchant_web
- admin_web
- backend

## التشغيل المحلي للـBackend
```bash
cd backend
npm install
npx prisma generate
# جهز DATABASE_URL في .env
npx prisma migrate dev --name init
npm run start:dev
```

## تشغيل Flutter
```bash
cd customer_app
flutter pub get
flutter run
```

ثم نفس الخطوات لـ driver_app.

## تنبيه
الحزمة الحالية هي build foundation متقدم وليست إطلاقًا إنتاجيًا مكتملًا. الخدمات الخارجية والاختبارات الميدانية والحماية التشغيلية مطلوبة قبل استقبال أموال أو عملاء حقيقيين.
