# حالة بناء عزوتنا

## مكتمل في هذه الدفعة
- API health
- OTP contract placeholder
- order quote/create/list/get/cancel contracts
- driver availability/offers/accept/status/custody/settlement contracts
- merchant dashboard/orders/accept/ready contracts
- owner dashboard/drivers/merchants/finance/custody-limit contracts
- customer and driver Flutter shells
- merchant/admin web shells

## غير مفعّل عمدًا حتى توفير الخدمات الخارجية
- SMS/OTP provider الحقيقي
- خرائط وGPS حقيقي
- قاعدة بيانات production
- تخزين صور الروشتات
- Push notifications
- حسابات النشر
- الدفع بالبطاقات

## ملاحظة
أي endpoint باسم PENDING أو placeholder لا يعتبر جاهزًا للإنتاج؛ هو عقد واضح لنقطة الربط القادمة.
