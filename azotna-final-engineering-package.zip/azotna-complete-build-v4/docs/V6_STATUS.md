# V6 status

Added:
- customer API client
- customer special-order screen
- driver API client
- driver live custody/availability contracts
- public configuration endpoint
- architecture documentation

Still external/production-only:
- real OTP
- real map/GPS/navigation
- secure image upload
- push notifications
- production DB/hosting
- app store signing/accounts
- field QA
