# Security baseline

- Never trust prices, distance, driver earnings, custody or role values sent by mobile apps.
- Calculate all money values server-side.
- Keep OTP secrets and API keys in environment variables.
- Store prescription images privately; use short-lived signed access URLs.
- Rate-limit OTP requests and login attempts.
- Require authorization on every customer/driver/merchant/admin resource.
- Use PostgreSQL transactions for order + ledger + custody changes.
- Keep immutable audit records for financial/admin changes.
- Do not log OTP codes, passwords, card data, prescription contents or access tokens.
- Encrypt production traffic with HTTPS.
- Back up the production database and test restore.
