# عزوتنا — Final launch plan

## Product scope
Assiut first:
- Restaurants
- Supermarkets
- Pharmacies
- Stores
- Special delivery request
- Cash on delivery
- Walk/bike/motorcycle/car couriers
- Merchant delivery or Azotna courier
- Initial driver custody cap: 700 EGP

## Technical completion
The repository contains the domain model, API contracts, order engine, ledger engine, pricing foundation, special-order flow, customer/driver shells, merchant/admin shells, and deployment templates.

## External activation still required
These cannot be truthfully marked active without credentials/accounts:
1. SMS/OTP provider
2. Maps/routing provider
3. Private object storage
4. Push notification provider
5. Production PostgreSQL/hosting
6. Google Play developer account
7. Apple Developer account
8. Optional payment gateway later

## Before first real order
- Run migrations on production DB.
- Enable HTTPS.
- Configure secrets.
- Enable OTP.
- Enable maps/routing.
- Enable private image storage.
- Enable push.
- Complete authorization middleware.
- Run integration/security tests.
- Pilot with a small set of merchants and drivers.
- Verify cash reconciliation daily.

## Expansion
After stable Assiut operations, add cities through configuration rather than cloning the system.
