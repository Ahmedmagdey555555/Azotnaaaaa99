# عزوتنا — Architecture

Customer App / Driver App
        |
      HTTPS API
        |
   NestJS Backend
   |      |       |
 PostgreSQL  Storage  Notifications
        |
 Admin / Merchant dashboards

## Money rule
All prices, driver earnings, custody, settlements and platform margins are calculated/validated server-side.

## Special order
Customer -> request + pickup/dropoff + attachment
-> dispatch -> driver pickup
-> driver records purchase/quote
-> customer approves
-> purchase -> delivery
-> cash settlement

## Expansion
Start with Assiut, but all city/store/driver configuration is data-driven so additional governorates can be enabled later.
