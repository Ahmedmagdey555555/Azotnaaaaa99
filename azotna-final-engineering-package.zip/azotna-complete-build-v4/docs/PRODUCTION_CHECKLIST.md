# عزوتنا — Production checklist

## Backend
- [x] Domain model
- [x] Roles
- [x] Order lifecycle
- [x] Special-order lifecycle
- [x] Custody rules (initial 700)
- [x] Audit model
- [x] Pricing service foundation
- [ ] Real JWT/OTP provider
- [ ] Real database migration
- [ ] Transactions for money/order writes
- [ ] Rate limiting
- [ ] Request validation on every DTO
- [ ] Error monitoring

## Customer
- [x] Category shell
- [ ] Login
- [ ] Address picker
- [ ] Store/product browsing
- [ ] Cart
- [ ] Checkout
- [ ] Order tracking
- [ ] Special order with photo
- [ ] Push notifications

## Driver
- [x] Online/offline
- [x] Custody display
- [ ] GPS tracking
- [ ] Offer matching
- [ ] Navigation
- [ ] Proof of delivery
- [ ] Settlement workflow

## Merchant
- [x] Dashboard shell
- [ ] Catalog CRUD
- [ ] Inventory
- [ ] Order workflow
- [ ] Merchant delivery option
- [ ] Settlement reports

## Owner/Admin
- [x] Dashboard shell
- [x] Finance foundation
- [x] Audit model
- [ ] RBAC enforcement across every route
- [ ] Live operations map
- [ ] Pricing configuration UI
- [ ] Reports/export

## External services
- [ ] Maps
- [ ] OTP/SMS
- [ ] Object storage
- [ ] Push notifications
- [ ] Production hosting/domain
- [ ] Google Play
- [ ] Apple App Store
- [ ] Card gateway later
